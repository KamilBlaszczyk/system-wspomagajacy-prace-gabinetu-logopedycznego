-- ---------------------------------------------------------
  --
  -- SIMPLE SQL Dump
  -- 
  -- nawa (at) yahoo (dot) com
  --
  -- Host Connection Info: localhost via TCP/IP
  -- Generation Time: April 07, 2018 at 22:12 PM ( Europe/Berlin )
  -- Server version: 5.5.5-10.1.28-MariaDB
  -- PHP Version: 7.1.11
  --
  -- ---------------------------------------------------------


  SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
  SET time_zone = "+00:00";
  /*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
  /*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
  /*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
  /*!40101 SET NAMES utf8 */;
  

  -- ---------------------------------------------------------
  --
  -- Table structure for table : `admin`
  --
  -- ---------------------------------------------------------
  CREATE TABLE `admin` (
  `id_admin` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(200) NOT NULL,
  `haslo` varchar(200) NOT NULL,
  `imie` varchar(200) NOT NULL,
  `mail` varchar(200) NOT NULL,
  PRIMARY KEY (`id_admin`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

  --
  -- Dumping data for table `admin`
  --
  INSERT INTO `admin` (`id_admin`, `login`, `haslo`, `imie`, `mail`) VALUES
(1, 'admin', '47bce5c74f589f4867dbd57e9ca9f808', 'Mateusz Bartelik', 'snaffx@wp.pl'),
(4, 'mati', '33c71afa38da081127ceead48dbfcd70', 'Mateusz Bartelik', 'snaffx@wp.pl');



  -- ---------------------------------------------------------
  --
  -- Table structure for table : `artykul`
  --
  -- ---------------------------------------------------------
  CREATE TABLE `artykul` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tytul` varchar(200) NOT NULL,
  `tresc` text NOT NULL,
  `obrazek` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

  --
  -- Dumping data for table `artykul`
  --
  INSERT INTO `artykul` (`id`, `tytul`, `tresc`, `obrazek`) VALUES
(1, 'test', '1sfdsg', 'default.jpg'),
(2, 'test0', 'fsdfsdg', 'default.jpg');



  -- ---------------------------------------------------------
  --
  -- Table structure for table : `kontakt`
  --
  -- ---------------------------------------------------------
  CREATE TABLE `kontakt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `opcja` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

  --
  -- Dumping data for table `kontakt`
  --
  INSERT INTO `kontakt` (`id`, `opcja`) VALUES
(1, 234),
(2, 'ul. Starogda?szczy?ska 15\nStarograd'),
(3, 'maciek@wp.pl');



  -- ---------------------------------------------------------
  --
  -- Table structure for table : `ustawienia`
  --
  -- ---------------------------------------------------------
  CREATE TABLE `ustawienia` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `wartosc` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

  --
  -- Dumping data for table `ustawienia`
  --
  INSERT INTO `ustawienia` (`id`, `wartosc`) VALUES
(1, 'Elekt'),
(2, 'Strona o logopiedii'),
(3, 'logopedia, gabinet, logo');



  -- ---------------------------------------------------------
  --
  -- Table structure for table : `zdjecia`
  --
  -- ---------------------------------------------------------
  CREATE TABLE `zdjecia` (
  `id_zdj` int(11) NOT NULL AUTO_INCREMENT,
  `sciezka` varchar(200) NOT NULL,
  PRIMARY KEY (`id_zdj`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

  --
  -- Dumping data for table `zdjecia`
  --
  INSERT INTO `zdjecia` (`id_zdj`, `sciezka`) VALUES
(4, '20180407150729.jpg');


  /*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
  /*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
  /*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;